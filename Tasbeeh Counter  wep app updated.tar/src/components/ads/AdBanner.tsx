'use client'

import { useEffect, useRef, useState } from 'react'
import { Skeleton } from '@/components/ui/skeleton'

// AdMob Ad Configuration
const ADMOB_CONFIG = {
  appId: 'ca-app-pub-9310607854623598~8279664166',
  bannerAdUnit: 'ca-app-pub-9310607854623598/5653500827',
  interstitialAdUnit: 'ca-app-pub-9310607854623598/5976934452'
}

interface AdBannerProps {
  className?: string
  showTestAd?: boolean
  placement?: 'home' | 'history' | 'settings'
}

export default function AdBanner({ className = '', showTestAd = false, placement = 'home' }: AdBannerProps) {
  const [adLoaded, setAdLoaded] = useState(false)
  const adContainerRef = useRef<HTMLDivElement>(null)
  const scriptRef = useRef<HTMLScriptElement | null>(null)

  useEffect(() => {
    // Load AdSense/AdMob script
    if (!scriptRef.current && typeof window !== 'undefined') {
      const script = document.createElement('script')
      script.src = 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-9310607854623598'
      script.async = true
      script.crossOrigin = 'anonymous'
      script.onload = () => setAdLoaded(true)
      script.onerror = () => console.error('AdSense script failed to load')
      document.head.appendChild(script)
      scriptRef.current = script
    }

    return () => {
      // Cleanup script if component unmounts
      if (scriptRef.current && document.head.contains(scriptRef.current)) {
        document.head.removeChild(scriptRef.current)
        scriptRef.current = null
      }
    }
  }, [])

  return (
    <div className={`w-full ${className}`} ref={adContainerRef}>
      {/* Ad Container */}
      <div className="w-full min-h-[100px] bg-slate-100 dark:bg-slate-800 rounded-lg overflow-hidden flex items-center justify-center">
        {!adLoaded && (
          <div className="w-full h-[100px]">
            <Skeleton className="w-full h-full" />
          </div>
        )}
        
        {/* Google AdSense Ad Unit */}
        <ins
          className="adsbygoogle block"
          style={{ display: 'block', minHeight: '100px' }}
          data-ad-client="ca-pub-9310607854623598"
          data-ad-slot={showTestAd ? '1234567890' : ADMOB_CONFIG.bannerAdUnit}
          data-ad-format="auto"
          data-full-width-responsive="true"
          data-ad-test={showTestAd ? 'on' : 'off'}
        />
      </div>
      
      {/* Ad Label for Transparency */}
      <p className="text-xs text-center text-gray-500 mt-2">
        Advertisement
      </p>
    </div>
  )
}

// Hook to load and show interstitial ads
export function useInterstitialAd() {
  const [adLoaded, setAdLoaded] = useState(false)
  const [showAd, setShowAd] = useState(false)

  const loadInterstitial = () => {
    // In a real implementation, this would load the AdMob interstitial
    // For web, we're showing a placeholder
    console.log('Loading interstitial ad:', ADMOB_CONFIG.interstitialAdUnit)
    setAdLoaded(true)
  }

  const showInterstitial = () => {
    if (adLoaded) {
      setShowAd(true)
      // Auto-hide after 3 seconds (or when user closes)
      setTimeout(() => {
        setShowAd(false)
      }, 3000)
    }
  }

  return { loadInterstitial, showInterstitial, showAd }
}

// Interstitial Ad Modal Component
export function InterstitialAd({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-[100] bg-black/80 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 rounded-lg max-w-md w-full p-6 text-center">
        <h3 className="text-xl font-bold mb-4">Advertisement</h3>
        
        {/* Interstitial Ad Container */}
        <div className="w-full min-h-[300px] bg-slate-100 dark:bg-slate-800 rounded-lg flex items-center justify-center mb-4">
          <ins
            className="adsbygoogle block"
            style={{ display: 'block', minHeight: '250px' }}
            data-ad-client="ca-pub-9310607854623598"
            data-ad-slot={ADMOB_CONFIG.interstitialAdUnit}
            data-ad-format="rectangle"
            data-full-width-responsive="true"
          />
        </div>
        
        <button
          onClick={onClose}
          className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-medium py-3 px-6 rounded-lg transition-colors"
        >
          Close Ad
        </button>
        
        <p className="text-xs text-gray-500 mt-3">
          Skip this ad after 3 seconds
        </p>
      </div>
    </div>
  )
}
