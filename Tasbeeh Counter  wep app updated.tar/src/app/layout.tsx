import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono, Amiri } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const amiri = Amiri({
  variable: "--font-amiri",
  subsets: ["arabic", "latin"],
  weight: ["400", "700"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "Tasbeeh Counter - #1 Digital Rosary & Zikr Reminder App",
  description: "World-class Islamic Tasbeeh Counter app with digital rosary, dhikr tracker, and zikr reminder. Track your prayers, maintain streaks, and connect with your faith. Features haptic feedback, multiple themes, and comprehensive analytics.",
  keywords: ["Tasbeeh Counter", "Digital Rosary", "Zikr Reminder", "Muslim Prayer Tracker", "Dhikr App", "Islamic Prayer Counter", "Digital Tasbih", "Islamic Prayer Beads", "Quran Dhikr", "Muslim Worship App"],
  authors: [{ name: "Tasbeeh Team" }],
  icons: {
    icon: "/logo.svg",
    apple: "/logo.svg",
  },
  openGraph: {
    title: "Tasbeeh Counter - #1 Digital Rosary & Zikr Reminder App",
    description: "Track your dhikr and tasbeeh with our beautiful digital counter. Features haptic feedback, themes, and analytics.",
    url: "/",
    siteName: "Tasbeeh Counter",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Tasbeeh Counter - #1 Digital Rosary App",
    description: "Track your dhikr and tasbeeh with our beautiful digital counter",
  },
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "Tasbeeh Counter",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  themeColor: "#00695C",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${amiri.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
