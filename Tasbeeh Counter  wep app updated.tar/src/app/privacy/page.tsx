import { Metadata } from 'next'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Shield, Eye, Database, Cookie, Trash2, Mail } from 'lucide-react'

export const metadata: Metadata = {
  title: 'Privacy Policy - Tasbeeh Counter',
  description: 'Learn how Tasbeeh Counter protects your privacy and handles your personal information.',
  keywords: ['privacy policy', 'data protection', 'Tasbeeh Counter privacy'],
}

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-emerald-50 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-emerald-100 dark:bg-emerald-900/30 rounded-full mb-6">
            <Shield className="w-10 h-10 text-emerald-600 dark:text-emerald-400" />
          </div>
          <h1 className="text-4xl font-bold text-slate-800 dark:text-white mb-4">
            Privacy Policy
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-300">
            Last Updated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
        </div>

        {/* Introduction */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">Introduction</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p>
              Tasbeeh Counter ("we", "our", or "us") respects your privacy and is committed to protecting your personal data. This privacy policy explains how we collect, use, disclose, and safeguard your information when you use our Tasbeeh Counter application.
            </p>
            <p>
              Please read this privacy policy carefully. If you do not agree with the terms of this privacy policy, please do not access the application.
            </p>
          </CardContent>
        </Card>

        {/* Data Collection */}
        <Card className="mb-6">
          <CardHeader>
            <div className="flex items-center gap-3">
              <Database className="w-6 h-6 text-emerald-600" />
              <CardTitle className="text-2xl">Information We Collect</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-6 text-gray-700 dark:text-gray-300">
            <div>
              <h3 className="text-xl font-semibold mb-3 text-slate-800 dark:text-white">1. Personal Information</h3>
              <p className="mb-2">We may collect the following types of personal information:</p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li><strong>Email Address:</strong> When you create an account or contact us</li>
                <li><strong>Name:</strong> Display name on your profile (optional)</li>
                <li><strong>Avatar:</strong> Profile picture (optional)</li>
                <li><strong>User Preferences:</strong> Theme, accent color, haptic feedback settings</li>
              </ul>
            </div>

            <div>
              <h3 className="text-xl font-semibold mb-3 text-slate-800 dark:text-white">2. Usage Data</h3>
              <p className="mb-2">We automatically collect information about how you use the application:</p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li><strong>Tasbeeh Sessions:</strong> Records of your dhikr sessions</li>
                <li><strong>Count Data:</strong> Number of recitations performed</li>
                <li><strong>Session Duration:</strong> Time spent on each session</li>
                <li><strong>Streak Information:</strong> Daily usage streaks</li>
                <li><strong>App Usage Patterns:</strong> Features used and time of use</li>
              </ul>
            </div>

            <div>
              <h3 className="text-xl font-semibold mb-3 text-slate-800 dark:text-white">3. Device Information</h3>
              <p className="mb-2">We may collect information about your device:</p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Device type and operating system</li>
                <li>Browser type and version</li>
                <li>Screen resolution and device identifiers</li>
                <li>IP address (anonymized)</li>
              </ul>
            </div>

            <div>
              <h3 className="text-xl font-semibold mb-3 text-slate-800 dark:text-white">4. Cookies and Tracking Technologies</h3>
              <div className="flex items-start gap-3">
                <Cookie className="w-5 h-5 text-emerald-600 mt-1 flex-shrink-0" />
                <div>
                  <p className="mb-2">We use cookies and similar technologies to:</p>
                  <ul className="list-disc list-inside space-y-2">
                    <li>Remember your preferences and settings</li>
                    <li>Analyze app performance and usage patterns</li>
                    <li>Provide personalized content and features</li>
                    <li>Show relevant advertisements</li>
                    <li>Improve security and prevent fraud</li>
                  </ul>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* How We Use Your Data */}
        <Card className="mb-6">
          <CardHeader>
            <div className="flex items-center gap-3">
              <Eye className="w-6 h-6 text-emerald-600" />
              <CardTitle className="text-2xl">How We Use Your Information</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p>We use your information for the following purposes:</p>
            <ul className="list-disc list-inside space-y-3 ml-4">
              <li><strong>Provide and Improve Services:</strong> To deliver, maintain, and improve our Tasbeeh Counter application</li>
              <li><strong>Personalization:</strong> To customize your experience based on your preferences</li>
              <li><strong>Data Synchronization:</strong> To sync your data across devices (if applicable)</li>
              <li><strong>Analytics:</strong> To understand how users interact with the app and improve features</li>
              <li><strong>Advertising:</strong> To show relevant advertisements and measure ad effectiveness</li>
              <li><strong>Security:</strong> To detect, prevent, and address technical issues and fraudulent activities</li>
              <li><strong>Legal Compliance:</strong> To comply with legal obligations and enforce our terms</li>
              <li><strong>Communication:</strong> To send important updates, security alerts, and support messages</li>
            </ul>
          </CardContent>
        </Card>

        {/* Data Sharing */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">Information Sharing</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p>We respect your privacy and do not sell your personal data. We may share your information only in the following circumstances:</p>
            
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-semibold mb-2 text-slate-800 dark:text-white">1. Service Providers</h3>
                <p>We may share data with third-party service providers who perform services on our behalf, such as:</p>
                <ul className="list-disc list-inside space-y-1 ml-4 mt-2">
                  <li>Cloud hosting and data storage services</li>
                  <li>Analytics services (Google Analytics)</li>
                  <li>Advertising services (Google AdMob/AdSense)</li>
                  <li>Customer support platforms</li>
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-2 text-slate-800 dark:text-white">2. Legal Requirements</h3>
                <p>We may disclose your information if required by law or to protect our rights:</p>
                <ul className="list-disc list-inside space-y-1 ml-4 mt-2">
                  <li>To comply with legal obligations</li>
                  <li>To protect our rights and property</li>
                  <li>To prevent fraud or security threats</li>
                  <li>To respond to legal requests</li>
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-2 text-slate-800 dark:text-white">3. Business Transfers</h3>
                <p>In the event of a merger, acquisition, or sale of assets, your information may be transferred to the new owner.</p>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-2 text-slate-800 dark:text-white">4. With Your Consent</h3>
                <p>We may share your information for other purposes with your explicit consent.</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* AdMob/AdSense Disclosure */}
        <Card className="mb-6 border-2 border-emerald-200 dark:border-emerald-800">
          <CardHeader>
            <CardTitle className="text-2xl text-emerald-700 dark:text-emerald-400">
              Google AdMob & AdSense Disclosure
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p className="font-semibold">
              Our application uses Google AdMob and AdSense for displaying advertisements.
            </p>
            
            <div className="bg-amber-50 dark:bg-amber-900/20 p-4 rounded-lg border border-amber-200 dark:border-amber-800">
              <h4 className="font-semibold mb-2 text-amber-800 dark:text-amber-400">Ad Unit Information:</h4>
              <ul className="space-y-2 text-sm">
                <li><strong>App ID:</strong> ca-app-pub-9310607854623598~8279664166</li>
                <li><strong>Banner Ad Unit:</strong> ca-app-pub-9310607854623598/5653500827</li>
                <li><strong>Interstitial Ad Unit:</strong> ca-app-pub-9310607854623598/5976934452</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-2">How Google Uses Data:</h4>
              <p className="mb-2">Google may use cookies and other tracking technologies to:</p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Personalize ads based on your interests</li>
                <li>Measure ad performance and effectiveness</li>
                <li>Prevent fraud and abuse</li>
                <li>Improve ad delivery and relevance</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-2">Your Ad Choices:</h4>
              <p className="mb-2">You can control how Google uses your data for advertising:</p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li><a href="https://www.google.com/settings/ads" target="_blank" rel="noopener noreferrer" className="text-emerald-600 hover:underline">Google Ads Settings</a></li>
                <li><a href="https://policies.google.com/technologies/ads" target="_blank" rel="noopener noreferrer" className="text-emerald-600 hover:underline">Google Advertising Privacy</a></li>
                <li><a href="https://www.aboutads.info/choices/" target="_blank" rel="noopener noreferrer" className="text-emerald-600 hover:underline">Digital Advertising Alliance</a></li>
                <li><a href="https://www.youronlinechoices.com/" target="_blank" rel="noopener noreferrer" className="text-emerald-600 hover:underline">Your Online Choices (EU)</a></li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* Data Retention */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">Data Retention and Deletion</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <div className="flex items-start gap-3">
              <Trash2 className="w-5 h-5 text-emerald-600 mt-1 flex-shrink-0" />
              <div>
                <h4 className="font-semibold mb-2">Retention Period</h4>
                <p className="mb-3">We retain your personal data for as long as necessary to provide our services and fulfill the purposes outlined in this privacy policy.</p>
                
                <h4 className="font-semibold mb-2">Your Right to Delete</h4>
                <p className="mb-2">You have the right to request deletion of your personal data at any time. To delete your account and data:</p>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>Contact us at the email address below</li>
                  <li>Specify that you want to delete your account</li>
                  <li>We will process your request within 30 days</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Your Rights */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">Your Privacy Rights</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p>Depending on your location, you may have the following rights regarding your personal data:</p>
            <ul className="list-disc list-inside space-y-3 ml-4">
              <li><strong>Access:</strong> Request a copy of your personal data</li>
              <li><strong>Correction:</strong> Request correction of inaccurate data</li>
              <li><strong>Deletion:</strong> Request deletion of your personal data</li>
              <li><strong>Portability:</strong> Request transfer of your data to another service</li>
              <li><strong>Objection:</strong> Object to processing of your data</li>
              <li><strong>Restriction:</strong> Request restriction of data processing</li>
              <li><strong>Withdraw Consent:</strong> Withdraw consent at any time</li>
            </ul>
            <p className="mt-4">
              To exercise these rights, please contact us using the information provided below.
            </p>
          </CardContent>
        </Card>

        {/* Children's Privacy */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">Children's Privacy</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p>
              Our application is not intended for children under the age of 13. We do not knowingly collect personal information from children under 13. If you are a parent or guardian and believe your child has provided us with personal information, please contact us immediately.
            </p>
            <p>
              If we discover that we have collected personal information from a child under 13 without parental consent, we will take steps to remove that information promptly.
            </p>
          </CardContent>
        </Card>

        {/* International Data Transfers */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">International Data Transfers</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p>
              Your information may be transferred to and processed in countries other than your country of residence. These countries may have different data protection laws. When we transfer your data, we ensure appropriate safeguards are in place to protect your privacy and data rights.
            </p>
          </CardContent>
        </Card>

        {/* Changes to Privacy Policy */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">Changes to This Privacy Policy</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p>
              We may update this privacy policy from time to time. We will notify you of any material changes by:
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>Posting the updated policy on this page</li>
              <li>Updating the "Last Updated" date</li>
              <li>Sending you an email notification (if you have an account)</li>
              <li>Displaying a prominent notice in the application</li>
            </ul>
            <p className="mt-4">
              Your continued use of the application after changes constitutes acceptance of the updated privacy policy.
            </p>
          </CardContent>
        </Card>

        {/* Contact */}
        <Card className="mb-6">
          <CardHeader>
            <div className="flex items-center gap-3">
              <Mail className="w-6 h-6 text-emerald-600" />
              <CardTitle className="text-2xl">Contact Us</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p>
              If you have any questions, concerns, or requests regarding this privacy policy or our data practices, please contact us:
            </p>
            <div className="bg-slate-50 dark:bg-slate-800 p-6 rounded-lg">
              <div className="space-y-3">
                <div>
                  <strong>Email:</strong>
                  <a href="mailto:privacy@tasbeehcounter.com" className="text-emerald-600 hover:underline ml-2">
                    privacy@tasbeehcounter.com
                  </a>
                </div>
                <div>
                  <strong>Application:</strong>
                  <span className="ml-2">Tasbeeh Counter</span>
                </div>
                <div>
                  <strong>Website:</strong>
                  <span className="ml-2">Available at your application store or web platform</span>
                </div>
              </div>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              We will respond to your inquiry within a reasonable time, typically within 30 days.
            </p>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center mt-12 text-gray-600 dark:text-gray-400">
          <p className="mb-4">
            <a href="/" className="text-emerald-600 hover:underline">
              ← Back to Tasbeeh Counter
            </a>
          </p>
          <p className="text-sm">
            © {new Date().getFullYear()} Tasbeeh Counter. All rights reserved.
          </p>
        </div>
      </div>
    </div>
  )
}
