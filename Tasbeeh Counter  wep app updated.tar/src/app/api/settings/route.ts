import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// PATCH /api/settings - Update user settings
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json()
    const { userId, theme, accentColor, hapticEnabled, soundEnabled } = body

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      )
    }

    // Check if settings exist
    let settings = await db.userSettings.findUnique({
      where: { userId }
    })

    if (settings) {
      // Update existing settings
      settings = await db.userSettings.update({
        where: { userId },
        data: {
          ...(theme !== undefined && { theme }),
          ...(accentColor !== undefined && { accentColor }),
          ...(hapticEnabled !== undefined && { hapticEnabled }),
          ...(soundEnabled !== undefined && { soundEnabled })
        }
      })
    } else {
      // Create new settings
      settings = await db.userSettings.create({
        data: {
          userId,
          theme: theme || 'light',
          accentColor: accentColor || 'green',
          hapticEnabled: hapticEnabled !== undefined ? hapticEnabled : true,
          soundEnabled: soundEnabled !== undefined ? soundEnabled : false
        }
      })
    }

    return NextResponse.json({ settings })
  } catch (error) {
    console.error('Error updating settings:', error)
    return NextResponse.json(
      { error: 'Failed to update settings' },
      { status: 500 }
    )
  }
}
