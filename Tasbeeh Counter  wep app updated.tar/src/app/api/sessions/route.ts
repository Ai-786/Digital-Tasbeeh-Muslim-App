import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/sessions - Get all sessions for a user
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      )
    }

    const sessions = await db.tasbeehSession.findMany({
      where: { userId },
      include: {
        tasbeeh: true
      },
      orderBy: { date: 'desc' },
      take: 50
    })

    return NextResponse.json({ sessions })
  } catch (error) {
    console.error('Error fetching sessions:', error)
    return NextResponse.json(
      { error: 'Failed to fetch sessions' },
      { status: 500 }
    )
  }
}

// POST /api/sessions - Create a new session
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { userId, tasbeehId, count, target, duration, completed } = body

    if (!userId || !tasbeehId) {
      return NextResponse.json(
        { error: 'User ID and Tasbeeh ID are required' },
        { status: 400 }
      )
    }

    // Verify tasbeeh exists
    const tasbeeh = await db.tasbeeh.findUnique({
      where: { id: tasbeehId }
    })

    if (!tasbeeh) {
      return NextResponse.json(
        { error: 'Tasbeeh not found' },
        { status: 404 }
      )
    }

    const session = await db.tasbeehSession.create({
      data: {
        userId,
        tasbeehId,
        count: count || 0,
        target: target || tasbeeh.defaultTarget,
        duration: duration || 0,
        completed: completed || false
      },
      include: {
        tasbeeh: true
      }
    })

    // Update user streak if session completed
    if (completed) {
      await updateUserStreak(userId)
    }

    return NextResponse.json({ session }, { status: 201 })
  } catch (error) {
    console.error('Error creating session:', error)
    return NextResponse.json(
      { error: 'Failed to create session' },
      { status: 500 }
    )
  }
}

async function updateUserStreak(userId: string) {
  const today = new Date()
  today.setHours(0, 0, 0, 0)

  const yesterday = new Date(today)
  yesterday.setDate(yesterday.getDate() - 1)

  // Check if user has a session today
  const sessionToday = await db.tasbeehSession.findFirst({
    where: {
      userId,
      date: {
        gte: today
      }
    }
  })

  // Check if user has a session yesterday
  const sessionYesterday = await db.tasbeehSession.findFirst({
    where: {
      userId,
      date: {
        gte: yesterday,
        lt: today
      }
    }
  })

  const user = await db.user.findUnique({
    where: { id: userId },
    select: { currentStreak: true, totalStreak: true }
  })

  if (!user) return

  let newStreak = user.currentStreak

  if (sessionToday) {
    // If already counted today, don't update streak
    return
  }

  if (sessionYesterday) {
    // Continue streak
    newStreak = user.currentStreak + 1
  } else {
    // Start new streak
    newStreak = 1
  }

  const totalStreak = Math.max(user.totalStreak, newStreak)

  await db.user.update({
    where: { id: userId },
    data: {
      currentStreak: newStreak,
      totalStreak
    }
  })
}
