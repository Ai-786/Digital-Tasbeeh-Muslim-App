import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/tasbeeh - Get all tasbeehs or filter by user
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const userId = searchParams.get('userId')
    const popular = searchParams.get('popular')

    let tasbeehs

    if (popular === 'true') {
      // Get popular tasbeehs only
      tasbeehs = await db.tasbeeh.findMany({
        where: {
          isPopular: true
        },
        orderBy: { defaultTarget: 'asc' }
      })
    } else if (userId) {
      // Get tasbeehs created by user + popular ones
      tasbeehs = await db.tasbeeh.findMany({
        where: {
          OR: [
            { userId },
            { isPopular: true }
          ]
        },
        orderBy: [
          { isPopular: 'desc' },
          { createdAt: 'desc' }
        ]
      })
    } else {
      // Get all tasbeehs
      tasbeehs = await db.tasbeeh.findMany({
        orderBy: [
          { isPopular: 'desc' },
          { createdAt: 'desc' }
        ]
      })
    }

    return NextResponse.json({ tasbeehs })
  } catch (error) {
    console.error('Error fetching tasbeehs:', error)
    return NextResponse.json(
      { error: 'Failed to fetch tasbeehs' },
      { status: 500 }
    )
  }
}

// POST /api/tasbeeh - Create a new custom tasbeeh
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { userId, name, arabicText, transliteration, translation, defaultTarget } = body

    if (!userId || !name) {
      return NextResponse.json(
        { error: 'User ID and Name are required' },
        { status: 400 }
      )
    }

    const tasbeeh = await db.tasbeeh.create({
      data: {
        userId,
        name,
        arabicText: arabicText || '',
        transliteration: transliteration || name,
        translation: translation || name,
        defaultTarget: defaultTarget || 33,
        isPopular: false,
        isCustom: true
      }
    })

    return NextResponse.json({ tasbeeh }, { status: 201 })
  } catch (error) {
    console.error('Error creating tasbeeh:', error)
    return NextResponse.json(
      { error: 'Failed to create tasbeeh' },
      { status: 500 }
    )
  }
}
