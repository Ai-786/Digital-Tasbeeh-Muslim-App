import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/users - Get or create a user
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const email = searchParams.get('email')
    const name = searchParams.get('name')

    if (!email) {
      return NextResponse.json(
        { error: 'Email is required' },
        { status: 400 }
      )
    }

    // Try to find existing user
    let user = await db.user.findUnique({
      where: { email },
      include: {
        settings: true
      }
    })

    // If user doesn't exist, create one
    if (!user) {
      user = await db.user.create({
        data: {
          email,
          name: name || null,
          settings: {
            create: {
              theme: 'light',
              accentColor: 'green',
              hapticEnabled: true,
              soundEnabled: false
            }
          }
        },
        include: {
          settings: true
        }
      })
    }

    return NextResponse.json({ user })
  } catch (error) {
    console.error('Error fetching user:', error)
    return NextResponse.json(
      { error: 'Failed to fetch user' },
      { status: 500 }
    )
  }
}

// PATCH /api/users - Update user profile
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json()
    const { userId, name, avatar } = body

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      )
    }

    const user = await db.user.update({
      where: { id: userId },
      data: {
        ...(name !== undefined && { name }),
        ...(avatar !== undefined && { avatar })
      },
      include: {
        settings: true
      }
    })

    return NextResponse.json({ user })
  } catch (error) {
    console.error('Error updating user:', error)
    return NextResponse.json(
      { error: 'Failed to update user' },
      { status: 500 }
    )
  }
}
