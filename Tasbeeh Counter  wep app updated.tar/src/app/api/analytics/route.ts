import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/analytics?userId={userId} - Get analytics data for a user
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      )
    }

    // Get user stats
    const user = await db.user.findUnique({
      where: { id: userId },
      select: {
        currentStreak: true,
        totalStreak: true,
        rank: true
      }
    })

    // Get total sessions count
    const totalSessions = await db.tasbeehSession.count({
      where: { userId }
    })

    // Get completed sessions
    const completedSessions = await db.tasbeehSession.count({
      where: {
        userId,
        completed: true
      }
    })

    // Get last 7 days of data for charts
    const sevenDaysAgo = new Date()
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7)
    sevenDaysAgo.setHours(0, 0, 0, 0)

    const dailyStats = await db.tasbeehSession.groupBy({
      by: ['date'],
      where: {
        userId,
        date: {
          gte: sevenDaysAgo
        }
      },
      _sum: {
        count: true
      },
      orderBy: {
        date: 'asc'
      }
    })

    // Format daily stats for chart
    const chartData = Array.from({ length: 7 }, (_, i) => {
      const date = new Date()
      date.setDate(date.getDate() - (6 - i))
      date.setHours(0, 0, 0, 0)
      date.setMilliseconds(0)
      
      const dayStat = dailyStats.find(stat => 
        new Date(stat.date).getDate() === date.getDate() &&
        new Date(stat.date).getMonth() === date.getMonth()
      )

      return {
        date: date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }),
        count: dayStat?._sum.count || 0
      }
    })

    // Get most used tasbeehs
    const popularTasbeehs = await db.tasbeehSession.groupBy({
      by: ['tasbeehId'],
      where: { userId },
      _count: {
        tasbeehId: true
      },
      _sum: {
        count: true
      },
      orderBy: {
        _count: {
          tasbeehId: 'desc'
        }
      },
      take: 5
    })

    const topTasbeehs = await Promise.all(
      popularTasbeehs.map(async (item) => {
        const tasbeeh = await db.tasbeeh.findUnique({
          where: { id: item.tasbeehId },
          select: {
            name: true,
            arabicText: true
          }
        })
        return {
          name: tasbeeh?.name || 'Unknown',
          arabicText: tasbeeh?.arabicText || '',
          sessions: item._count.tasbeehId,
          totalCount: item._sum.count || 0
        }
      })
    )

    return NextResponse.json({
      user,
      stats: {
        totalSessions,
        completedSessions,
        completionRate: totalSessions > 0 
          ? Math.round((completedSessions / totalSessions) * 100) 
          : 0
      },
      chartData,
      topTasbeehs
    })
  } catch (error) {
    console.error('Error fetching analytics:', error)
    return NextResponse.json(
      { error: 'Failed to fetch analytics' },
      { status: 500 }
    )
  }
}
