import { Metadata } from 'next'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { AlertTriangle, Info, BookOpen, Users, Heart, Globe } from 'lucide-react'

export const metadata: Metadata = {
  title: 'Disclaimer - Tasbeeh Counter',
  description: 'Important disclaimer regarding the use of Tasbeeh Counter for religious purposes.',
  keywords: ['disclaimer', 'religious disclaimer', 'Tasbeeh Counter disclaimer'],
}

export default function Disclaimer() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-emerald-50 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-amber-100 dark:bg-amber-900/30 rounded-full mb-6">
            <AlertTriangle className="w-10 h-10 text-amber-600 dark:text-amber-400" />
          </div>
          <h1 className="text-4xl font-bold text-slate-800 dark:text-white mb-4">
            Disclaimer
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-300">
            Last Updated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
        </div>

        {/* Main Disclaimer */}
        <Card className="mb-6 border-2 border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-900/10">
          <CardHeader>
            <CardTitle className="text-2xl text-amber-800 dark:text-amber-400">
              Important: Please Read Carefully
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p className="text-lg font-semibold">
              Tasbeeh Counter is a digital tool designed to assist users in tracking their dhikr (remembrance of Allah) and prayers. This disclaimer contains important information about the limitations and appropriate use of this application.
            </p>
            <div className="bg-white dark:bg-slate-800 p-6 rounded-lg border border-amber-300 dark:border-amber-700">
              <p className="font-semibold text-amber-800 dark:text-amber-400 mb-2">
                By using Tasbeeh Counter, you acknowledge and agree that:
              </p>
              <ul className="list-disc list-inside space-y-2">
                <li>This application is not a substitute for traditional prayer methods</li>
                <li>It does not provide religious guidance or fatwas</li>
                <li>The content is for educational and assistance purposes only</li>
                <li>You should consult qualified religious scholars for guidance</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* Not Religious Authority */}
        <Card className="mb-6">
          <CardHeader>
            <div className="flex items-center gap-3">
              <Info className="w-6 h-6 text-emerald-600" />
              <CardTitle className="text-2xl">Not a Religious Authority</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p className="font-semibold mb-3">
              Tasbeeh Counter is NOT a religious authority and does not:
            </p>
            <ul className="list-disc list-inside space-y-3 ml-4">
              <li>
                <strong>Issue Religious Rulings (Fatwas):</strong> The App does not provide religious rulings or opinions on Islamic matters.
              </li>
              <li>
                <strong>Offer Theological Interpretations:</strong> Content translations and meanings are for general guidance and may vary by Islamic school of thought.
              </li>
              <li>
                <strong>Guarantee Spiritual Benefits:</strong> We cannot guarantee or make claims about spiritual outcomes from using this application.
              </li>
              <li>
                <strong>Replace Religious Scholars:</strong> Users should always consult qualified Islamic scholars for religious guidance.
              </li>
              <li>
                <strong>Substitute Religious Texts:</strong> This is a supplementary tool and does not replace the Quran or Hadith.
              </li>
            </ul>
          </CardContent>
        </Card>

        {/* Accuracy of Content */}
        <Card className="mb-6">
          <CardHeader>
            <div className="flex items-center gap-3">
              <BookOpen className="w-6 h-6 text-emerald-600" />
              <CardTitle className="text-2xl">Accuracy of Content</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p className="mb-3">
              While we strive to provide accurate and authentic content, please note:
            </p>
            <ul className="list-disc list-inside space-y-3 ml-4">
              <li>
                <strong>Arabic Text:</strong> Quranic verses and dhikr phrases are based on common transliterations. Minor variations may exist in different Islamic traditions.
              </li>
              <li>
                <strong>Translations:</strong> English translations are provided for understanding and may not capture the full depth of the original Arabic text.
              </li>
              <li>
                <strong>Transliterations:</strong> Romanized Arabic is an approximation and may vary in pronunciation guides.
              </li>
              <li>
                <strong>Target Counts:</strong> Suggested counts (33, 99, 100) are based on common practices but not religious obligations.
              </li>
            </ul>
            <div className="bg-amber-50 dark:bg-amber-900/20 p-4 rounded-lg border border-amber-200 dark:border-amber-800 mt-4">
              <p className="text-sm">
                <strong>Verification:</strong> Users are encouraged to verify important religious content with authentic sources such as the Quran, authentic Hadith collections, or qualified religious scholars.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Religious Practices */}
        <Card className="mb-6">
          <CardHeader>
            <div className="flex items-center gap-3">
              <Heart className="w-6 h-6 text-emerald-600" />
              <CardTitle className="text-2xl">Personal and Cultural Practices</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p className="mb-3">
              Islamic practices may vary across different cultures, schools of thought, and personal preferences. Tasbeeh Counter:
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>Does not endorse any particular Islamic school of thought (Madhhab)</li>
              <li>Respects all valid Islamic traditions and practices</li>
              <li>Allows users to customize their own tasbeehs and practices</li>
              <li>Does not impose any specific method of counting or dhikr</li>
              <li>Encourages users to follow the guidance of their religious authorities</li>
            </ul>
            <p className="mt-4">
              What is considered authentic or preferred practice may vary between different Islamic scholars and communities. Users should follow the guidance of their trusted religious leaders.
            </p>
          </CardContent>
        </Card>

        {/* Technical Limitations */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">Technical Limitations</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p className="mb-3">
              Tasbeeh Counter is a software application and as such has certain limitations:
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li><strong>Accuracy of Counting:</strong> While designed to be accurate, technical issues may occur. Users should verify counts if in doubt.</li>
              <li><strong>Data Loss:</strong> Session history and user data may be lost due to technical issues, device failure, or account deletion.</li>
              <li><strong>Service Availability:</strong> The App may experience downtime, bugs, or technical difficulties.</li>
              <li><strong>Device Compatibility:</strong> Not all features may work on all devices or operating systems.</li>
              <li><strong>Internet Connection:</strong> Some features may require internet connectivity.</li>
            </ul>
            <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800 mt-4">
              <p className="text-sm">
                <strong>Recommendation:</strong> For important religious practices, consider using traditional physical tasbeeh beads as a backup or verification method.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* No Warranty */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">No Warranty</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p className="font-semibold mb-3">
              TASBEEH COUNTER IS PROVIDED "AS IS" AND "AS AVAILABLE" WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO:
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>Merchantability</li>
              <li>Fitness for a particular purpose</li>
              <li>Non-INFRINGEMENT</li>
              <li>Accuracy or reliability of content</li>
              <li>Uninterrupted or error-free operation</li>
              <li>Security of data</li>
              <li>Freedom from viruses or other harmful code</li>
            </ul>
            <p className="mt-4">
              We do not guarantee that the App will meet your requirements or that its operation will be uninterrupted or error-free.
            </p>
          </CardContent>
        </Card>

        {/* User Responsibility */}
        <Card className="mb-6">
          <CardHeader>
            <div className="flex items-center gap-3">
              <Users className="w-6 h-6 text-emerald-600" />
              <CardTitle className="text-2xl">User Responsibility</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p className="mb-3">
              Users of Tasbeeh Counter are responsible for:
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>Verifying religious content with authentic sources</li>
              <li>Consulting qualified religious scholars for guidance</li>
              <li>Using the App in accordance with Islamic principles</li>
              <li>Maintaining their own backup of important data</li>
              <li>Using the App at their own risk and discretion</li>
              <li>Ensuring they are in a proper state for prayer (wudu, etc.)</li>
              <li>Being mindful of the time and place when using the App</li>
            </ul>
          </CardContent>
        </Card>

        {/* Third-Party Content */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">Third-Party Content and Services</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p className="mb-3">
              Tasbeeh Counter may contain links to third-party websites, content, or services, and may display third-party advertisements. We are not responsible for:
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>The accuracy, reliability, or quality of third-party content</li>
              <li>The practices or policies of third-party websites</li>
              <li>Any damages or losses resulting from third-party interactions</li>
              <li>Third-party advertisements and their content</li>
            </ul>
            <p className="mt-4">
              Visiting third-party websites is at your own risk. We encourage users to review the privacy policies and terms of service of any third-party websites they visit.
            </p>
          </CardContent>
        </Card>

        {/* Cultural Sensitivity */}
        <Card className="mb-6">
          <CardHeader>
            <div className="flex items-center gap-3">
              <Globe className="w-6 h-6 text-emerald-600" />
              <CardTitle className="text-2xl">Cultural and Regional Considerations</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p className="mb-3">
              Tasbeeh Counter is used by Muslims around the world. Please be aware that:
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>Islamic practices may vary significantly between regions and cultures</li>
              <li>Preferred methods of dhikr may differ</li>
              <li>Language translations may not reflect all regional nuances</li>
              <li>Cultural sensitivities should be respected</li>
              <li>Time zones and prayer times vary by location</li>
            </ul>
            <p className="mt-4">
              The App aims to be inclusive and respectful of diverse Islamic traditions while remaining neutral on matters of legitimate scholarly disagreement.
            </p>
          </CardContent>
        </Card>

        {/* Spiritual Claims */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">No Spiritual Claims</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p className="mb-3">
              Tasbeeh Counter makes no claims regarding:
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>Spiritual benefits or rewards from using the App</li>
              <li>Effectiveness of dhikr practices tracked in the App</li>
              <li>Any religious blessings or barakah associated with use</li>
              <li>Sins being forgiven through App usage</li>
              <li>Any guaranteed outcomes from counting methods</li>
            </ul>
            <div className="bg-emerald-50 dark:bg-emerald-900/20 p-4 rounded-lg border border-emerald-200 dark:border-emerald-800 mt-4">
              <p className="text-sm text-emerald-800 dark:text-emerald-400">
                <strong>Important:</strong> Spiritual benefits in Islam come from sincere intention (niyyah), correct practice, and Allah's mercy alone—not from using any particular app or tool.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Limitation of Liability */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">Limitation of Liability</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p>
              To the maximum extent permitted by applicable law, Tasbeeh Counter, its developers, and affiliates shall not be liable for any direct, indirect, incidental, special, consequential, or punitive damages arising from:
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>Use or inability to use the App</li>
              <li>Reliance on any content provided in the App</li>
              <li>Errors or inaccuracies in the content</li>
              <li>Loss of data or session history</li>
              <li>Technical issues or service interruptions</li>
              <li>Third-party content or advertisements</li>
              <li>Any religious or spiritual outcomes</li>
            </ul>
            <p className="mt-4">
              This limitation applies even if we have been advised of the possibility of such damages.
            </p>
          </CardContent>
        </Card>

        {/* Updates to Disclaimer */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">Updates to This Disclaimer</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p>
              We may update this disclaimer from time to time to reflect changes in our practices, services, or applicable laws. Updated versions will be posted on this page with a revised "Last Updated" date.
            </p>
            <p>
              Your continued use of Tasbeeh Counter after any changes to this disclaimer constitutes your acceptance of the updated terms.
            </p>
          </CardContent>
        </Card>

        {/* Contact */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">Questions or Concerns</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p>
              If you have any questions about this disclaimer or any concerns about the content or functionality of Tasbeeh Counter, please contact us:
            </p>
            <div className="bg-slate-50 dark:bg-slate-800 p-6 rounded-lg">
              <div className="space-y-3">
                <div>
                  <strong>Email:</strong>
                  <a href="mailto:support@tasbeehcounter.com" className="text-emerald-600 hover:underline ml-2">
                    support@tasbeehcounter.com
                  </a>
                </div>
                <div>
                  <strong>Subject:</strong>
                  <span className="ml-2">Disclaimer Inquiry</span>
                </div>
              </div>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              We take your concerns seriously and will respond within a reasonable timeframe.
            </p>
          </CardContent>
        </Card>

        {/* Related Documents */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">Related Documents</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-gray-700 dark:text-gray-300">
            <p>
              For complete information about using Tasbeeh Counter, please also review:
            </p>
            <ul className="space-y-2">
              <li>
                <a href="/privacy" className="text-emerald-600 hover:underline font-semibold">
                  Privacy Policy →
                </a>
                <p className="text-sm text-gray-600 dark:text-gray-400">How we collect and use your data</p>
              </li>
              <li>
                <a href="/terms" className="text-emerald-600 hover:underline font-semibold">
                  Terms and Conditions →
                </a>
                <p className="text-sm text-gray-600 dark:text-gray-400">Rules for using the application</p>
              </li>
            </ul>
          </CardContent>
        </Card>

        {/* Final Notice */}
        <Card className="mb-6 border-2 border-emerald-200 dark:border-emerald-800">
          <CardHeader>
            <CardTitle className="text-2xl text-emerald-700 dark:text-emerald-400">
              Final Notice
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p className="text-lg">
              Tasbeeh Counter is created with the sincere intention of helping Muslims in their spiritual journey. We ask Allah to accept our efforts and guide us to what is best.
            </p>
            <p className="text-center italic text-emerald-700 dark:text-emerald-400 mt-6">
              "And remember your Lord much and exalt Him in the evening and the morning." - Quran 3:41
            </p>
            <p className="text-center font-semibold mt-4">
              May Allah accept your prayers and dhikr. 🤲
            </p>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center mt-12 text-gray-600 dark:text-gray-400">
          <p className="mb-4">
            <a href="/" className="text-emerald-600 hover:underline">
              ← Back to Tasbeeh Counter
            </a>
          </p>
          <p className="text-sm">
            © {new Date().getFullYear()} Tasbeeh Counter. All rights reserved.
          </p>
        </div>
      </div>
    </div>
  )
}
