import { Metadata } from 'next'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { FileText, AlertTriangle, CheckCircle, XCircle, Scale } from 'lucide-react'

export const metadata: Metadata = {
  title: 'Terms and Conditions - Tasbeeh Counter',
  description: 'Read the terms and conditions for using Tasbeeh Counter application.',
  keywords: ['terms and conditions', 'terms of service', 'Tasbeeh Counter terms'],
}

export default function TermsAndConditions() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-emerald-50 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-emerald-100 dark:bg-emerald-900/30 rounded-full mb-6">
            <FileText className="w-10 h-10 text-emerald-600 dark:text-emerald-400" />
          </div>
          <h1 className="text-4xl font-bold text-slate-800 dark:text-white mb-4">
            Terms and Conditions
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-300">
            Last Updated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
        </div>

        {/* Introduction */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">Introduction</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p>
              Welcome to Tasbeeh Counter. These Terms and Conditions ("Terms") govern your use of the Tasbeeh Counter application ("App", "Service", or "Platform"). By accessing or using the App, you agree to be bound by these Terms.
            </p>
            <p>
              Please read these Terms carefully before using the App. If you do not agree to these Terms, you may not access or use the App.
            </p>
          </CardContent>
        </Card>

        {/* Acceptance of Terms */}
        <Card className="mb-6">
          <CardHeader>
            <div className="flex items-center gap-3">
              <CheckCircle className="w-6 h-6 text-emerald-600" />
              <CardTitle className="text-2xl">Acceptance of Terms</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p>
              By accessing or using Tasbeeh Counter, you acknowledge that you have read, understood, and agree to be bound by these Terms. If you are using the App on behalf of an organization, you represent that you have the authority to bind that organization to these Terms.
            </p>
            <p>
              If you do not agree to these Terms, you must immediately discontinue your use of the App. Your continued use of the App after any changes to these Terms constitutes your acceptance of the updated Terms.
            </p>
          </CardContent>
        </Card>

        {/* Age Requirement */}
        <Card className="mb-6">
          <CardHeader>
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-6 h-6 text-amber-600" />
              <CardTitle className="text-2xl">Age Requirement</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p>
              By using Tasbeeh Counter, you represent and warrant that:
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>You are at least 13 years of age</li>
              <li>If you are under 18, you have obtained parental or guardian consent to use the App</li>
              <li>You have the legal capacity to enter into these Terms</li>
              <li>You will comply with all applicable laws and regulations</li>
            </ul>
            <div className="bg-amber-50 dark:bg-amber-900/20 p-4 rounded-lg border border-amber-200 dark:border-amber-800">
              <p className="text-sm font-semibold text-amber-800 dark:text-amber-400">
                Parental supervision is recommended for users under 18. We are not responsible for minors' use of the App without parental consent.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Description of Service */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">Description of Service</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p>
              Tasbeeh Counter is a digital dhikr and prayer tracking application that provides:
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>Digital counter for tracking dhikr recitations</li>
              <li>Pre-loaded popular tasbeehs with Arabic text and translations</li>
              <li>Custom tasbeeh creation and management</li>
              <li>Session history and analytics</li>
              <li>Streak tracking and gamification features</li>
              <li>Theme customization (light/dark mode, accent colors)</li>
              <li>User profiles and settings</li>
              <li>Advertisements through Google AdMob/AdSense</li>
            </ul>
            <p className="mt-4">
              The App is provided "as is" and may include features, functionalities, or content that change over time. We reserve the right to modify, suspend, or discontinue any aspect of the App at any time without prior notice.
            </p>
          </CardContent>
        </Card>

        {/* User Responsibilities */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">User Responsibilities</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p className="font-semibold">As a user of Tasbeeh Counter, you agree to:</p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>Use the App for lawful and legitimate purposes only</li>
              <li>Provide accurate and current information</li>
              <li>Maintain the security of your account credentials</li>
              <li>Not share your account with others</li>
              <li>Respect the religious and cultural nature of the content</li>
              <li>Not attempt to reverse engineer or hack the App</li>
              <li>Not use automated tools to access the App</li>
              <li>Not interfere with the App's operation or security</li>
              <li>Not upload or share inappropriate content</li>
              <li>Comply with all applicable laws and regulations</li>
            </ul>
          </CardContent>
        </Card>

        {/* Prohibited Activities */}
        <Card className="mb-6">
          <CardHeader>
            <div className="flex items-center gap-3">
              <XCircle className="w-6 h-6 text-red-600" />
              <CardTitle className="text-2xl">Prohibited Activities</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p>You may NOT use Tasbeeh Counter to:</p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>Violate any local, state, national, or international law</li>
              <li>Infringe upon the intellectual property rights of others</li>
              <li>Harass, abuse, or harm other users</li>
              <li>Distribute spam, malware, or malicious code</li>
              <li>Attempt to gain unauthorized access to our systems</li>
              <li>Disrupt the normal operation of the App</li>
              <li>Use the App for fraudulent or deceptive purposes</li>
              <li>Collect or store personal data of other users</li>
              <li>Modify, adapt, or create derivative works of the App</li>
              <li>Remove any proprietary notices or labels from the App</li>
            </ul>
            <div className="bg-red-50 dark:bg-red-900/20 p-4 rounded-lg border border-red-200 dark:border-red-800">
              <p className="text-sm font-semibold text-red-800 dark:text-red-400">
                Violation of these prohibitions may result in immediate termination of your account and potential legal action.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Intellectual Property */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">Intellectual Property</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p>
              All content, features, and functionality of Tasbeeh Counter are owned by us and are protected by international copyright, trademark, and other intellectual property laws.
            </p>
            <div>
              <h3 className="text-lg font-semibold mb-2 text-slate-800 dark:text-white">What We Own:</h3>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>The App software and source code</li>
                <li>The design, layout, and user interface</li>
                <li>Pre-loaded tasbeeh content and translations</li>
                <li>Brand names, logos, and trademarks</li>
                <li>All other original content and materials</li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-2 text-slate-800 dark:text-white">What You Own:</h3>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Custom tasbeehs you create</li>
                <li>Your session history and usage data</li>
                <li>Your user-generated content (within reason)</li>
              </ul>
            </div>
            <p className="mt-4">
              By using the App, you grant us a non-exclusive, royalty-free license to use, store, and display your content solely for providing the App's services.
            </p>
          </CardContent>
        </Card>

        {/* Privacy Policy */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">Privacy Policy</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p>
              Your privacy is important to us. Our collection and use of personal information is governed by our Privacy Policy, which is incorporated into these Terms by reference.
            </p>
            <div className="bg-emerald-50 dark:bg-emerald-900/20 p-4 rounded-lg">
              <p className="font-semibold text-emerald-800 dark:text-emerald-400 mb-2">
                Please read our Privacy Policy to understand:
              </p>
              <ul className="list-disc list-inside space-y-1 text-sm">
                <li>What information we collect</li>
                <li>How we use your information</li>
                <li>With whom we share your information</li>
                <li>Your rights regarding your data</li>
              </ul>
            </div>
            <p className="mt-4">
              <a href="/privacy" className="text-emerald-600 hover:underline font-semibold">
                View our full Privacy Policy →
              </a>
            </p>
          </CardContent>
        </Card>

        {/* Advertising */}
        <Card className="mb-6 border-2 border-emerald-200 dark:border-emerald-800">
          <CardHeader>
            <CardTitle className="text-2xl text-emerald-700 dark:text-emerald-400">
              Advertising and AdMob Integration
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p className="font-semibold">
              Tasbeeh Counter displays advertisements through Google AdMob and AdSense to support the continued development and maintenance of the App.
            </p>
            
            <div className="space-y-3">
              <div>
                <h4 className="font-semibold mb-2">Ad Unit Information:</h4>
                <ul className="space-y-2 text-sm">
                  <li><strong>App ID:</strong> ca-app-pub-9310607854623598~8279664166</li>
                  <li><strong>Banner Ad Unit:</strong> ca-app-pub-9310607854623598/5653500827</li>
                  <li><strong>Interstitial Ad Unit:</strong> ca-app-pub-9310607854623598/5976934452</li>
                </ul>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Ad Placement:</h4>
                <ul className="list-disc list-inside space-y-1">
                  <li>Banner ads appear on Home and History screens</li>
                  <li>Interstitial ads show after completing a session</li>
                  <li>Ads are non-intrusive and respectful of prayer time</li>
                  <li>We comply with Google's AdMob policies</li>
                </ul>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Third-Party Advertising:</h4>
                <p>
                  Google and third-party vendors may use cookies to serve ads based on your prior visits to our website or other websites. You can opt out of personalized ads by visiting <a href="https://www.google.com/settings/ads" target="_blank" rel="noopener noreferrer" className="text-emerald-600 hover:underline">Google Ads Settings</a>.
                </p>
              </div>
            </div>

            <div className="bg-amber-50 dark:bg-amber-900/20 p-4 rounded-lg border border-amber-200 dark:border-amber-800">
              <p className="text-sm">
                <strong>Important:</strong> We are not responsible for the content, accuracy, or availability of third-party advertisements. Clicking on ads may take you to external websites over which we have no control.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Disclaimer */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">Disclaimer</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p>
              Tasbeeh Counter is provided for religious and spiritual purposes. The App is not intended to replace traditional prayer methods or provide religious guidance.
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>The App is provided "as is" without any warranties</li>
              <li>We do not guarantee accuracy of translations or transliterations</li>
              <li>The App may contain errors or inaccuracies</li>
              <li>Religious content is for guidance and may vary by tradition</li>
              <li>We are not responsible for any spiritual or religious outcomes</li>
              <li>Users should consult religious scholars for guidance</li>
            </ul>
            <p className="mt-4">
              For a detailed disclaimer, please see our <a href="/disclaimer" className="text-emerald-600 hover:underline font-semibold">full Disclaimer page</a>.
            </p>
          </CardContent>
        </Card>

        {/* Limitation of Liability */}
        <Card className="mb-6">
          <CardHeader>
            <div className="flex items-center gap-3">
              <Scale className="w-6 h-6 text-emerald-600" />
              <CardTitle className="text-2xl">Limitation of Liability</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p>
              To the fullest extent permitted by law, Tasbeeh Counter and its developers, officers, directors, employees, and agents shall not be liable for:
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>Any indirect, incidental, special, or consequential damages</li>
              <li>Loss of profits, data, or business opportunities</li>
              <li>Technical issues, bugs, or service interruptions</li>
              <li>Third-party content or advertisements</li>
              <li>User conduct or content generated by users</li>
              <li>Any damages exceeding the amount you paid for the App (if any)</li>
            </ul>
            <p className="mt-4">
              Some jurisdictions do not allow the exclusion of certain warranties or the limitation of liability for consequential damages, so the above limitations may not apply to you.
            </p>
          </CardContent>
        </Card>

        {/* Indemnification */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">Indemnification</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p>
              You agree to indemnify, defend, and hold harmless Tasbeeh Counter and its affiliates, officers, directors, employees, and agents from and against any claims, damages, obligations, losses, liabilities, costs, or debt, and expenses (including but not limited to attorney's fees), resulting from or arising out of:
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>Your use of and access to the App</li>
              <li>Your violation of these Terms</li>
              <li>Your violation of any third-party rights</li>
              <li>Your violation of any applicable law or regulation</li>
              <li>Any content you submit or post on the App</li>
            </ul>
          </CardContent>
        </Card>

        {/* Termination */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">Termination</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <div>
              <h3 className="text-lg font-semibold mb-2 text-slate-800 dark:text-white">By You:</h3>
              <p className="mb-2">You may terminate your account and stop using the App at any time by:</p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Contacting us to request account deletion</li>
                <li>Uninstalling the App from your device</li>
                <li>Simply discontinuing use of the App</li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-2 text-slate-800 dark:text-white">By Us:</h3>
              <p className="mb-2">We reserve the right to terminate or suspend your account and access to the App if:</p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>You violate these Terms</li>
                <li>You engage in prohibited activities</li>
                <li>We are required to do so by law</li>
                <li>We discontinue the App or services</li>
                <li>We believe it is in our best interest</li>
              </ul>
            </div>
            <p className="mt-4">
              Upon termination, your right to use the App will immediately cease. All provisions of these Terms which by their nature should survive termination shall survive.
            </p>
          </CardContent>
        </Card>

        {/* Changes to Terms */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">Changes to These Terms</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p>
              We reserve the right to modify these Terms at any time. Changes will be effective immediately upon posting to the App. Your continued use of the App after such changes constitutes your acceptance of the updated Terms.
            </p>
            <p>
              We will make reasonable efforts to notify you of material changes through:
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>Email notification (if you have an account)</li>
              <li>In-app notification or banner</li>
              <li>Posting the updated Terms on this page</li>
              <li>Updating the "Last Updated" date</li>
            </ul>
            <p className="mt-4">
              It is your responsibility to review these Terms periodically for changes.
            </p>
          </CardContent>
        </Card>

        {/* Governing Law */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">Governing Law and Dispute Resolution</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p>
              These Terms shall be governed by and construed in accordance with the laws of [Your Country/Jurisdiction], without regard to its conflict of law provisions.
            </p>
            <p>
              Any disputes arising from or relating to these Terms or the App shall be resolved through:
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>Good faith negotiation between the parties</li>
              <li>Mediation or arbitration, if negotiation fails</li>
              <li>Courts of competent jurisdiction as a last resort</li>
            </ul>
            <p className="mt-4">
              Each party agrees to submit to the personal jurisdiction of the courts located in [Your City, Country] for any legal proceedings arising from these Terms.
            </p>
          </CardContent>
        </Card>

        {/* Severability */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">Severability</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p>
              If any provision of these Terms is found to be unenforceable or invalid, that provision will be limited or eliminated to the minimum extent necessary so that the remaining Terms will remain in full force and effect and continue to be valid and enforceable.
            </p>
          </CardContent>
        </Card>

        {/* Entire Agreement */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">Entire Agreement</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p>
              These Terms, together with our Privacy Policy and any other legal notices published on the App, constitute the entire agreement between you and Tasbeeh Counter regarding the use of the App.
            </p>
            <p>
              These Terms supersede all prior agreements, understandings, and communications between you and Tasbeeh Counter regarding the App, whether written or oral.
            </p>
          </CardContent>
        </Card>

        {/* Contact */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">Contact Us</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-gray-700 dark:text-gray-300">
            <p>
              If you have any questions about these Terms, please contact us:
            </p>
            <div className="bg-slate-50 dark:bg-slate-800 p-6 rounded-lg">
              <div className="space-y-3">
                <div>
                  <strong>Email:</strong>
                  <a href="mailto:support@tasbeehcounter.com" className="text-emerald-600 hover:underline ml-2">
                    support@tasbeehcounter.com
                  </a>
                </div>
                <div>
                  <strong>Application:</strong>
                  <span className="ml-2">Tasbeeh Counter</span>
                </div>
              </div>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              We will respond to your inquiry within a reasonable time.
            </p>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center mt-12 text-gray-600 dark:text-gray-400">
          <p className="mb-4">
            <a href="/" className="text-emerald-600 hover:underline">
              ← Back to Tasbeeh Counter
            </a>
          </p>
          <p className="text-sm mb-2">
            By using Tasbeeh Counter, you acknowledge that you have read, understood, and agree to these Terms and Conditions.
          </p>
          <p className="text-sm">
            © {new Date().getFullYear()} Tasbeeh Counter. All rights reserved.
          </p>
        </div>
      </div>
    </div>
  )
}
