'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Switch } from '@/components/ui/switch'
import { Slider } from '@/components/ui/slider'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { toast } from '@/hooks/use-toast'
import { Moon, Sun, Settings, User, Trophy, Share2, Plus, History, Star, Award, Flame, TrendingUp, Menu, X, ExternalLink } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import AdBanner, { InterstitialAd, useInterstitialAd } from '@/components/ads/AdBanner'

interface Tasbeeh {
  id: string
  name: string
  arabicText: string
  transliteration: string
  translation: string
  defaultTarget: number
  isPopular: boolean
  isCustom: boolean
}

interface Session {
  id: string
  tasbeehName: string
  count: number
  target: number
  duration: number
  date: string
}

const popularTasbeehs: Tasbeeh[] = [
  {
    id: '1',
    name: 'Subhan Allah',
    arabicText: 'سُبْحَانَ اللَّهِ',
    transliteration: 'Subhan Allah',
    translation: 'Glory be to Allah',
    defaultTarget: 33,
    isPopular: true,
    isCustom: false
  },
  {
    id: '2',
    name: 'Alhamdulillah',
    arabicText: 'الْحَمْدُ لِلَّهِ',
    transliteration: 'Alhamdulillah',
    translation: 'Praise be to Allah',
    defaultTarget: 33,
    isPopular: true,
    isCustom: false
  },
  {
    id: '3',
    name: 'Allahu Akbar',
    arabicText: 'اللَّهُ أَكْبَرُ',
    transliteration: 'Allahu Akbar',
    translation: 'Allah is the Greatest',
    defaultTarget: 34,
    isPopular: true,
    isCustom: false
  },
  {
    id: '4',
    name: 'La ilaha illallah',
    arabicText: 'لَا إِلَٰهَ إِلَّا اللَّهُ',
    transliteration: 'La ilaha illallah',
    translation: 'There is no god but Allah',
    defaultTarget: 100,
    isPopular: true,
    isCustom: false
  },
  {
    id: '5',
    name: 'Astaghfirullah',
    arabicText: 'أَسْتَغْفِرُ اللَّهَ',
    transliteration: 'Astaghfirullah',
    translation: 'I seek forgiveness from Allah',
    defaultTarget: 100,
    isPopular: true,
    isCustom: false
  },
  {
    id: '6',
    name: 'La hawla wa la quwwata',
    arabicText: 'لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ',
    transliteration: 'La hawla wa la quwwata illa billah',
    translation: 'There is no might and no power except by Allah',
    defaultTarget: 100,
    isPopular: true,
    isCustom: false
  }
]

const accentColors = {
  green: { bg: 'bg-green-600', hover: 'hover:bg-green-700', text: 'text-green-600', light: 'bg-green-100' },
  cyan: { bg: 'bg-cyan-600', hover: 'hover:bg-cyan-700', text: 'text-cyan-600', light: 'bg-cyan-100' },
  blue: { bg: 'bg-blue-600', hover: 'hover:bg-blue-700', text: 'text-blue-600', light: 'bg-blue-100' },
  purple: { bg: 'bg-purple-600', hover: 'hover:bg-purple-700', text: 'text-purple-600', light: 'bg-purple-100' }
}

export default function TasbeehApp() {
  const [count, setCount] = useState(0)
  const [target, setTarget] = useState(33)
  const [isPlaying, setIsPlaying] = useState(false)
  const [timer, setTimer] = useState(0)
  const [selectedTasbeeh, setSelectedTasbeeh] = useState<Tasbeeh>(popularTasbeehs[0])
  const [customTasbeehs, setCustomTasbeehs] = useState<Tasbeeh[]>([])
  const [history, setHistory] = useState<Session[]>([])
  const [theme, setTheme] = useState<'light' | 'dark'>('light')
  const [accentColor, setAccentColor] = useState<keyof typeof accentColors>('green')
  const [hapticEnabled, setHapticEnabled] = useState(true)
  const [soundEnabled, setSoundEnabled] = useState(false)
  const [currentStreak, setCurrentStreak] = useState(7)
  const [totalSessions, setTotalSessions] = useState(156)
  const [rank, setRank] = useState(5)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [newTasbeehName, setNewTasbeehName] = useState('')
  const [newTasbeehTarget, setNewTasbeehTarget] = useState([33])
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const { loadInterstitial, showInterstitial, showAd } = useInterstitialAd()

  const colors = accentColors[accentColor]

  useEffect(() => {
    let interval: NodeJS.Timeout
    if (isPlaying) {
      interval = setInterval(() => {
        setTimer(prev => prev + 1)
      }, 1000)
    }
    return () => clearInterval(interval)
  }, [isPlaying])

  const triggerHapticFeedback = () => {
    if (hapticEnabled && 'vibrate' in navigator) {
      const vibrationPattern = count === target - 1 
        ? [200, 100, 200, 100, 200] 
        : count % 33 === 0 && count > 0 
          ? [100, 50, 100]
          : [50]
      
      navigator.vibrate(vibrationPattern)
    }
  }

  const incrementCount = () => {
    if (!isPlaying) setIsPlaying(true)
    
    triggerHapticFeedback()
    setCount(prev => {
      const newCount = prev + 1
      if (newCount >= target) {
        completeSession()
        return 0
      }
      return newCount
    })
  }

  const decrementCount = () => {
    if (count > 0) {
      setCount(prev => prev - 1)
    }
  }

  const completeSession = () => {
    const session: Session = {
      id: Date.now().toString(),
      tasbeehName: selectedTasbeeh.name,
      count: target,
      target,
      duration: timer,
      date: new Date().toISOString()
    }
    setHistory(prev => [session, ...prev])
    setTotalSessions(prev => prev + 1)
    setIsPlaying(false)
    setTimer(0)
    
    toast({
      title: "Mashallah! 🌙",
      description: `You completed ${selectedTasbeeh.name} ${target} times!`,
      variant: "default",
    })

    if (hapticEnabled && 'vibrate' in navigator) {
      navigator.vibrate([200, 100, 200, 100, 200, 100, 200])
    }

    // Load and show interstitial ad after completion
    loadInterstitial()
    setTimeout(() => {
      showInterstitial()
    }, 500)
  }

  const selectTasbeeh = (tasbeeh: Tasbeeh) => {
    setSelectedTasbeeh(tasbeeh)
    setTarget(tasbeeh.defaultTarget)
    setCount(0)
    setTimer(0)
    setIsPlaying(false)
    setIsMenuOpen(false)
  }

  const addCustomTasbeeh = () => {
    if (!newTasbeehName.trim()) return

    const customTasbeeh: Tasbeeh = {
      id: Date.now().toString(),
      name: newTasbeehName,
      arabicText: '',
      transliteration: newTasbeehName,
      translation: newTasbeehName,
      defaultTarget: newTasbeehTarget[0],
      isPopular: false,
      isCustom: true
    }

    setCustomTasbeehs(prev => [...prev, customTasbeeh])
    setNewTasbeehName('')
    setNewTasbeehTarget([33])
    setIsDialogOpen(false)
    
    toast({
      title: "Tasbeeh Added! ✨",
      description: "Your custom Tasbeeh has been created.",
    })
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const calculateStreak = () => {
    const today = new Date()
    const dates = history.map(h => new Date(h.date).toDateString())
    let streak = 0
    let currentDate = today

    while (dates.includes(currentDate.toDateString())) {
      streak++
      currentDate.setDate(currentDate.getDate() - 1)
    }
    return streak
  }

  const toggleTheme = () => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light')
  }

  const allTasbeehs = [...popularTasbeehs, ...customTasbeehs]

  // Load interstitial ad on component mount
  useEffect(() => {
    loadInterstitial()
  }, [])

  return (
    <div className={`min-h-screen ${theme === 'dark' ? 'dark' : ''}`}>
      <div className={`min-h-screen bg-gradient-to-br from-green-50 via-white to-emerald-50 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900 transition-colors duration-300`}>
        {/* Header */}
        <header className={`${colors.bg} text-white px-4 py-4 flex items-center justify-between relative overflow-hidden`}>
          <div className="absolute inset-0 opacity-10">
            <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
              <defs>
                <pattern id="islamic-pattern" patternUnits="userSpaceOnUse" width="20" height="20">
                  <path d="M10 0 L20 10 L10 20 L0 10 Z" fill="none" stroke="currentColor" strokeWidth="0.5"/>
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#islamic-pattern)"/>
            </svg>
          </div>
          <div className="flex items-center gap-3 relative z-10">
            <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
              <Avatar className="w-10 h-10">
                <AvatarImage src="" />
                <AvatarFallback className={`${colors.bg} text-white`}>US</AvatarFallback>
              </Avatar>
            </div>
            <div>
              <h1 className="text-lg font-bold">Tasbeeh Counter</h1>
              <p className="text-xs text-white/80">Let's remember Allah together</p>
            </div>
          </div>
          <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="relative z-10">
                <Menu className="w-6 h-6 text-white" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-80">
              <SheetHeader>
                <SheetTitle>Select Tasbeeh</SheetTitle>
                <SheetDescription>Choose a dhikr to recite</SheetDescription>
              </SheetHeader>
              <ScrollArea className="mt-6 h-[calc(100vh-200px)]">
                <div className="space-y-2">
                  {allTasbeehs.map((tasbeeh) => (
                    <Card 
                      key={tasbeeh.id} 
                      className={`cursor-pointer transition-all hover:scale-[1.02] ${
                        selectedTasbeeh.id === tasbeeh.id ? colors.bg + ' text-white' : 'hover:bg-gray-100 dark:hover:bg-slate-800'
                      }`}
                      onClick={() => selectTasbeeh(tasbeeh)}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h3 className="font-bold text-lg mb-1">{tasbeeh.name}</h3>
                            {tasbeeh.arabicText && (
                              <p className={`text-2xl mb-1 ${selectedTasbeeh.id === tasbeeh.id ? 'text-white' : 'text-emerald-700 dark:text-emerald-400'}`} style={{ fontFamily: 'Amiri, serif' }}>
                                {tasbeeh.arabicText}
                              </p>
                            )}
                            {tasbeeh.transliteration && (
                              <p className={`text-sm ${selectedTasbeeh.id === tasbeeh.id ? 'text-white/80' : 'text-gray-600 dark:text-gray-400'}`}>
                                {tasbeeh.transliteration}
                              </p>
                            )}
                            <p className={`text-sm mt-1 ${selectedTasbeeh.id === tasbeeh.id ? 'text-white/80' : 'text-gray-600 dark:text-gray-400'}`}>
                              {tasbeeh.translation}
                            </p>
                          </div>
                          {tasbeeh.isPopular && <Star className="w-5 h-5 text-yellow-400 flex-shrink-0" />}
                        </div>
                        <Badge variant="secondary" className="mt-3">
                          Target: {tasbeeh.defaultTarget}
                        </Badge>
                      </CardContent>
                    </Card>
                  ))}
                  
                  <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                    <DialogTrigger asChild>
                      <Button variant="outline" className="w-full" onClick={() => setIsDialogOpen(true)}>
                        <Plus className="w-4 h-4 mr-2" />
                        Create Custom Tasbeeh
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Create Custom Tasbeeh</DialogTitle>
                        <DialogDescription>Add your own dhikr to track</DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4 py-4">
                        <div>
                          <Label htmlFor="tasbeeh-name">Tasbeeh Name</Label>
                          <Input
                            id="tasbeeh-name"
                            value={newTasbeehName}
                            onChange={(e) => setNewTasbeehName(e.target.value)}
                            placeholder="e.g., Astaghfirullah"
                          />
                        </div>
                        <div>
                          <Label htmlFor="tasbeeh-target">Target Count</Label>
                          <Slider
                            id="tasbeeh-target"
                            value={newTasbeehTarget}
                            onValueChange={setNewTasbeehTarget}
                            min={10}
                            max={1000}
                            step={1}
                            className="mt-2"
                          />
                          <div className="text-center mt-2">
                            <span className="text-2xl font-bold text-emerald-600">{newTasbeehTarget[0]}</span>
                          </div>
                        </div>
                      </div>
                      <DialogFooter>
                        <Button onClick={addCustomTasbeeh} className={colors.bg}>
                          Create Tasbeeh
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </ScrollArea>
            </SheetContent>
          </Sheet>
        </header>

        {/* Main Content */}
        <main className="px-4 py-6 pb-48">
          {/* Current Tasbeeh Display */}
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-8"
          >
            <h2 className="text-3xl font-bold text-slate-800 dark:text-white mb-2">
              {selectedTasbeeh.name}
            </h2>
            {selectedTasbeeh.arabicText && (
              <p className="text-4xl text-emerald-700 dark:text-emerald-400 mb-2" style={{ fontFamily: 'Amiri, serif' }}>
                {selectedTasbeeh.arabicText}
              </p>
            )}
            {selectedTasbeeh.transliteration && (
              <p className="text-lg text-gray-600 dark:text-gray-300">
                {selectedTasbeeh.transliteration}
              </p>
            )}
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
              {selectedTasbeeh.translation}
            </p>
          </motion.div>

          {/* Counter Section */}
          <Card className="mb-6 overflow-hidden">
            <CardContent className="p-6">
              {/* Timer Display */}
              <div className="text-center mb-6">
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-slate-100 dark:bg-slate-800 rounded-full">
                  <Clock className="w-4 h-4 text-slate-600 dark:text-slate-400" />
                  <span className="text-2xl font-mono font-bold text-slate-800 dark:text-white">
                    {formatTime(timer)}
                  </span>
                  <Badge variant={isPlaying ? "default" : "secondary"} className={isPlaying ? colors.bg : ''}>
                    {isPlaying ? 'Active' : 'Paused'}
                  </Badge>
                </div>
              </div>

              {/* Large Counter Button */}
              <div className="flex justify-center mb-6">
                <motion.div
                  whileTap={{ scale: 0.95 }}
                  whileHover={{ scale: 1.02 }}
                  className="relative"
                >
                  <Button
                    onClick={incrementCount}
                    onContextMenu={(e) => {
                      e.preventDefault()
                      decrementCount()
                    }}
                    className={`w-64 h-64 rounded-full ${colors.bg} ${colors.hover} text-white shadow-2xl flex flex-col items-center justify-center transition-all duration-200 hover:shadow-emerald-500/30`}
                    size="lg"
                  >
                    <div className="absolute inset-0 rounded-full bg-gradient-to-br from-white/20 to-transparent pointer-events-none" />
                    <div className="relative z-10">
                      <div className="text-7xl font-bold mb-2">{count}</div>
                      <div className="text-sm opacity-80">/ {target}</div>
                    </div>
                  </Button>
                  {/* Progress Ring */}
                  <svg className="absolute -inset-4 w-72 h-72 -rotate-90 pointer-events-none">
                    <circle
                      cx="144"
                      cy="144"
                      r="140"
                      stroke="currentColor"
                      strokeWidth="8"
                      fill="none"
                      className="text-slate-200 dark:text-slate-700"
                    />
                    <circle
                      cx="144"
                      cy="144"
                      r="140"
                      stroke="currentColor"
                      strokeWidth="8"
                      fill="none"
                      strokeDasharray={`${(count / target) * 880} 880`}
                      className={`${colors.text} transition-all duration-300`}
                    />
                  </svg>
                </motion.div>
              </div>

              {/* Progress Bar */}
              <div className="space-y-2 mb-4">
                <div className="flex justify-between text-sm text-gray-600 dark:text-gray-400">
                  <span>Progress</span>
                  <span className="font-bold">{Math.round((count / target) * 100)}%</span>
                </div>
                <Progress value={(count / target) * 100} className="h-3" />
              </div>

              {/* Action Buttons */}
              <div className="flex justify-center gap-4">
                <Button
                  variant="outline"
                  onClick={() => { setCount(0); setTimer(0); setIsPlaying(false) }}
                  className="flex-1"
                >
                  Reset
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="flex-1"
                >
                  {isPlaying ? 'Pause' : 'Start'}
                </Button>
              </div>

              <p className="text-xs text-center text-gray-500 mt-4">
                Tap to increment · Long press to decrement
              </p>
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            <Card className="text-center">
              <CardContent className="p-4">
                <div className="flex justify-center mb-2">
                  <div className="w-10 h-10 rounded-full bg-orange-100 dark:bg-orange-900/30 flex items-center justify-center">
                    <Flame className="w-5 h-5 text-orange-600 dark:text-orange-400" />
                  </div>
                </div>
                <div className="text-2xl font-bold text-slate-800 dark:text-white">{currentStreak}</div>
                <div className="text-xs text-gray-600 dark:text-gray-400">Day Streak</div>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-4">
                <div className="flex justify-center mb-2">
                  <div className="w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                    <Trophy className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                  </div>
                </div>
                <div className="text-2xl font-bold text-slate-800 dark:text-white">{totalSessions}</div>
                <div className="text-xs text-gray-600 dark:text-gray-400">Sessions</div>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-4">
                <div className="flex justify-center mb-2">
                  <div className="w-10 h-10 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center">
                    <Award className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                  </div>
                </div>
                <div className="text-2xl font-bold text-slate-800 dark:text-white">Top {rank}%</div>
                <div className="text-xs text-gray-600 dark:text-gray-400">Your Rank</div>
              </CardContent>
            </Card>
          </div>

          {/* Tabs Section */}
          <Tabs defaultValue="history" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-4">
              <TabsTrigger value="history">History</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>

            {/* History Tab */}
            <TabsContent value="history" className="space-y-4">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">Recent Sessions</CardTitle>
                    <Badge variant="outline" className="flex items-center gap-1">
                      <TrendingUp className="w-3 h-3" />
                      {history.length} total
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-80">
                    {history.length === 0 ? (
                      <div className="text-center py-12">
                        <History className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                        <p className="text-gray-500">No sessions yet</p>
                        <p className="text-sm text-gray-400">Complete a tasbeeh to see history</p>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {history.map((session) => (
                          <motion.div
                            key={session.id}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800 rounded-lg"
                          >
                            <div>
                              <h4 className="font-semibold text-slate-800 dark:text-white">{session.tasbeehName}</h4>
                              <p className="text-sm text-gray-600 dark:text-gray-400">
                                {formatDate(session.date)}
                              </p>
                            </div>
                            <div className="text-right">
                              <div className="text-lg font-bold text-emerald-600 dark:text-emerald-400">
                                {session.count}/{session.target}
                              </div>
                              <div className="text-xs text-gray-500">{formatTime(session.duration)}</div>
                            </div>
                          </motion.div>
                        ))}
                      </div>
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Settings Tab */}
            <TabsContent value="settings" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Preferences</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Theme Toggle */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {theme === 'light' ? (
                        <Sun className="w-5 h-5 text-yellow-600" />
                      ) : (
                        <Moon className="w-5 h-5 text-blue-600" />
                      )}
                      <div>
                        <p className="font-medium text-slate-800 dark:text-white">Dark Mode</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Switch theme</p>
                      </div>
                    </div>
                    <Switch checked={theme === 'dark'} onCheckedChange={toggleTheme} />
                  </div>

                  {/* Haptic Feedback */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-5 h-5 rounded-full bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center">
                        <div className="w-2 h-2 bg-purple-600 dark:bg-purple-400 rounded-full" />
                      </div>
                      <div>
                        <p className="font-medium text-slate-800 dark:text-white">Haptic Feedback</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Vibration on tap</p>
                      </div>
                    </div>
                    <Switch checked={hapticEnabled} onCheckedChange={setHapticEnabled} />
                  </div>

                  {/* Sound */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-5 h-5 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center">
                        <div className="w-2 h-2 bg-emerald-600 dark:bg-emerald-400 rounded-full" />
                      </div>
                      <div>
                        <p className="font-medium text-slate-800 dark:text-white">Sound</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Sound on tap</p>
                      </div>
                    </div>
                    <Switch checked={soundEnabled} onCheckedChange={setSoundEnabled} />
                  </div>

                  {/* Accent Color */}
                  <div>
                    <p className="font-medium text-slate-800 dark:text-white mb-3">Accent Color</p>
                    <div className="flex gap-3">
                      {(Object.keys(accentColors) as Array<keyof typeof accentColors>).map((color) => (
                        <button
                          key={color}
                          onClick={() => setAccentColor(color)}
                          className={`w-12 h-12 rounded-full ${accentColors[color].bg} ${
                            accentColor === color ? 'ring-4 ring-offset-2 ring-offset-white dark:ring-offset-slate-900 ring-emerald-600' : ''
                          } transition-all`}
                          aria-label={`Select ${color} color`}
                        />
                      ))}
                    </div>
                  </div>

                  {/* Target Adjustment */}
                  <div>
                    <p className="font-medium text-slate-800 dark:text-white mb-3">Target Count</p>
                    <Slider
                      value={[target]}
                      onValueChange={(value) => setTarget(value[0])}
                      min={10}
                      max={1000}
                      step={1}
                      className="mt-2"
                    />
                    <div className="text-center mt-2">
                      <span className="text-2xl font-bold text-emerald-600">{target}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Share & Profile */}
              <Card>
                <CardContent className="p-6 space-y-4">
                  <Button 
                    className="w-full" 
                    variant="outline"
                    onClick={() => {
                      toast({
                        title: "Share Feature! 📱",
                        description: "Share your progress with friends!",
                      })
                    }}
                  >
                    <Share2 className="w-4 h-4 mr-2" />
                    Share App
                  </Button>
                  <Button 
                    className="w-full" 
                    variant="outline"
                    onClick={() => {
                      toast({
                        title: "Profile Feature! 👤",
                        description: "Manage your profile settings!",
                      })
                    }}
                  >
                    <User className="w-4 h-4 mr-2" />
                    Edit Profile
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </main>

        {/* Fixed Ad Banner and Footer at Bottom */}
        <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-700 z-50">
          {/* Ad Banner */}
          <div className="px-4 py-3">
            <AdBanner placement="home" className="max-w-4xl mx-auto" />
          </div>
          
          {/* Footer with Legal Links */}
          <footer className="bg-slate-100 dark:bg-slate-900 border-t border-slate-200 dark:border-slate-700 py-2 px-4">
            <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-center gap-4 text-xs text-gray-600 dark:text-gray-400">
              <span>© {new Date().getFullYear()} Tasbeeh Counter</span>
              <span className="hidden sm:inline">•</span>
              <a href="/privacy" className="hover:text-emerald-600 dark:hover:text-emerald-400 flex items-center gap-1">
                Privacy Policy
                <ExternalLink className="w-3 h-3" />
              </a>
              <a href="/terms" className="hover:text-emerald-600 dark:hover:text-emerald-400 flex items-center gap-1">
                Terms
                <ExternalLink className="w-3 h-3" />
              </a>
              <a href="/disclaimer" className="hover:text-emerald-600 dark:hover:text-emerald-400 flex items-center gap-1">
                Disclaimer
                <ExternalLink className="w-3 h-3" />
              </a>
              <a href="/ads.txt" className="hover:text-emerald-600 dark:hover:text-emerald-400 flex items-center gap-1">
                ads.txt
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </footer>
        </div>

        {/* Interstitial Ad Modal */}
        <InterstitialAd isOpen={showAd} onClose={() => {}} />
      </div>
    </div>
  )
}

function Clock({ className }: { className?: string }) {
  const [time, setTime] = useState(new Date())
  
  useEffect(() => {
    const interval = setInterval(() => setTime(new Date()), 1000)
    return () => clearInterval(interval)
  }, [])

  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <circle cx="12" cy="12" r="10" />
      <path d="M12 6v6l4 2" />
    </svg>
  )
}
