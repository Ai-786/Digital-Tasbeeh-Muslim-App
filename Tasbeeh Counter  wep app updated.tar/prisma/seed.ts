import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  console.log('Seeding database...')

  // Seed popular tasbeehs
  const popularTasbeehs = [
    {
      name: 'Subhan Allah',
      arabicText: 'سُبْحَانَ اللَّهِ',
      transliteration: 'Subhan Allah',
      translation: 'Glory be to Allah',
      defaultTarget: 33,
      isPopular: true,
      isCustom: false
    },
    {
      name: 'Alhamdulillah',
      arabicText: 'الْحَمْدُ لِلَّهِ',
      transliteration: 'Alhamdulillah',
      translation: 'Praise be to Allah',
      defaultTarget: 33,
      isPopular: true,
      isCustom: false
    },
    {
      name: 'Allahu Akbar',
      arabicText: 'اللَّهُ أَكْبَرُ',
      transliteration: 'Allahu Akbar',
      translation: 'Allah is the Greatest',
      defaultTarget: 34,
      isPopular: true,
      isCustom: false
    },
    {
      name: 'La ilaha illallah',
      arabicText: 'لَا إِلَٰهَ إِلَّا اللَّهُ',
      transliteration: 'La ilaha illallah',
      translation: 'There is no god but Allah',
      defaultTarget: 100,
      isPopular: true,
      isCustom: false
    },
    {
      name: 'Astaghfirullah',
      arabicText: 'أَسْتَغْفِرُ اللَّهَ',
      transliteration: 'Astaghfirullah',
      translation: 'I seek forgiveness from Allah',
      defaultTarget: 100,
      isPopular: true,
      isCustom: false
    },
    {
      name: 'La hawla wa la quwwata',
      arabicText: 'لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ',
      transliteration: 'La hawla wa la quwwata illa billah',
      translation: 'There is no might and no power except by Allah',
      defaultTarget: 100,
      isPopular: true,
      isCustom: false
    },
    {
      name: 'SubhanAllahi wa bihamdihi',
      arabicText: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ',
      transliteration: 'SubhanAllahi wa bihamdihi',
      translation: 'Glory be to Allah and praise Him',
      defaultTarget: 100,
      isPopular: true,
      isCustom: false
    },
    {
      name: 'Allahumma salli ala Muhammad',
      arabicText: 'اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ',
      transliteration: 'Allahumma salli ala Muhammad',
      translation: 'O Allah, send prayers upon Muhammad',
      defaultTarget: 100,
      isPopular: true,
      isCustom: false
    }
  ]

  for (const tasbeeh of popularTasbeehs) {
    await prisma.tasbeeh.upsert({
      where: { 
        id: tasbeeh.name.toLowerCase().replace(/\s+/g, '-')
      },
      update: {},
      create: {
        id: tasbeeh.name.toLowerCase().replace(/\s+/g, '-'),
        ...tasbeeh
      }
    })
  }

  console.log('Seeding completed successfully!')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
